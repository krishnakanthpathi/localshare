"""
TCP Client Engine
Handles outbound file transfers, multi-folder batch transmission, Gzip compression, and AES-256-GCM encryption.
"""

import socket
import os
import time
import uuid
import threading
from app.config import TCP_PORT, SOCKET_BUFFER_SIZE, BUFFER_SIZE, PARALLEL_STREAMS_THRESHOLD, PARALLEL_WORKERS, state
from app.utils import is_compressible_file, compute_file_hash
from app.transfer.protocol import send_message, receive_message
from app.processing.engine import processor
from app.security.encryption import encrypt_text
from app.queue.models import TransferTask, BatchTransferTask, TransferStatus
from app.queue.manager import queue_manager
from app.storage import record_transfer

def send_text_snippet(
    target_ip: str,
    text: str,
    target_port: int = TCP_PORT,
    sender_name: str = None,
    encrypt: bool = None
) -> tuple[bool, str]:
    """Send an encrypted or plain text snippet to target IP."""
    use_encryption = state.encryption_enabled if encrypt is None else encrypt
    payload_text = text

    if use_encryption and state.encryption_key:
        try:
            payload_text = encrypt_text(text, state.encryption_key)
        except Exception as e:
            return False, f"Encryption failed: {e}"

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(5.0)
    try:
        sock.connect((target_ip, target_port))
        send_message(sock, {
            "type": "TEXT_SNIPPET",
            "text": payload_text,
            "sender": sender_name or state.device_name,
            "is_encrypted": use_encryption,
            "timestamp": time.time()
        })
        return True, "Snippet sent successfully."
    except Exception as e:
        return False, f"Failed to send snippet: {e}"
    finally:
        sock.close()

def send_parallel_file(
    target_ip: str,
    file_path: str,
    rel_path: str = None,
    target_port: int = TCP_PORT,
    num_workers: int = PARALLEL_WORKERS,
    progress_callback = None
) -> tuple[bool, str]:
    """Send a large file concurrently across 4 parallel TCP sockets."""
    if not os.path.exists(file_path):
        return False, f"File not found: {file_path}"

    filename = os.path.basename(file_path)
    relative_name = rel_path or filename
    filesize = os.path.getsize(file_path)
    transfer_id = str(uuid.uuid4())
    file_checksum = compute_file_hash(file_path)

    # 1. Compute part boundaries
    part_size = filesize // num_workers
    parts = []
    for i in range(num_workers):
        offset = i * part_size
        length = (filesize - offset) if (i == num_workers - 1) else part_size
        parts.append({"part_index": i, "offset": offset, "length": length})

    # 2. Control Connection
    control_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        control_sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        control_sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, SOCKET_BUFFER_SIZE)
        control_sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, SOCKET_BUFFER_SIZE)
    except Exception:
        pass
    control_sock.settimeout(30.0)

    # Register active outbound transfer record in state
    transfer_record = {
        "id": transfer_id,
        "filename": filename,
        "rel_path": relative_name,
        "filepath": file_path,
        "total_bytes": filesize,
        "received_bytes": 0,
        "transferred_bytes": 0,
        "progress_percent": 0.0,
        "direction": "OUTBOUND",
        "target_ip": target_ip,
        "status": "IN_PROGRESS",
        "encrypted": False,
        "compressed": False,
        "parallel_streams": num_workers,
        "speed": 0.0,
        "speed_mb": 0.0,
        "speed_mbps": 0.0,
        "eta": 0.0,
        "start_time": time.time(),
        "end_time": 0.0
    }
    state.transfers.insert(0, transfer_record)

    try:
        control_sock.connect((target_ip, target_port))
        
        # Send PARALLEL_FILE_HEADER
        send_message(control_sock, {
            "type": "PARALLEL_FILE_HEADER",
            "transfer_id": transfer_id,
            "filename": filename,
            "rel_path": relative_name,
            "filesize": filesize,
            "num_parts": num_workers,
            "parts": parts,
            "checksum": file_checksum
        })

        resp = receive_message(control_sock)
        if not resp or resp.get("type") != "PARALLEL_FILE_RESPONSE" or resp.get("status") != "ACCEPT":
            transfer_record["status"] = "FAILED"
            err = resp.get("reason", "Rejected by peer") if resp else "No response"
            return False, f"Peer rejected parallel transfer: {err}"

        # Coordinate multi-part streaming across 4 concurrent worker sockets with async ACK synchronization
        bytes_sent_lock = threading.Lock()
        total_sent_bytes = [0]
        start_time = time.time()
        worker_errors = []
        ack_lock = threading.Lock()
        ack_thread_stop = threading.Event()
        final_ack_msg = [None]
        received_any_ack = [False]

        def _control_ack_listener():
            while not ack_thread_stop.is_set():
                try:
                    control_sock.settimeout(0.5)
                    msg = receive_message(control_sock)
                    if not msg:
                        continue
                    msg_type = msg.get("type")
                    if msg_type == "PROGRESS_ACK":
                        rec_bytes = msg.get("received_bytes", 0)
                        with ack_lock:
                            received_any_ack[0] = True
                            transfer_record["received_bytes"] = rec_bytes
                            metrics = processor.calculate_metrics(
                                transferred_bytes=rec_bytes,
                                total_bytes=filesize,
                                start_time=start_time,
                                transfer_id=transfer_id
                            )
                            transfer_record["progress_percent"] = metrics.get("percent", 0.0)
                            transfer_record["speed"] = metrics.get("speed", 0.0)
                            transfer_record["speed_mb"] = metrics.get("speed_mb", 0.0)
                            transfer_record["speed_mbps"] = metrics.get("speed_mbps", 0.0)
                            transfer_record["eta"] = metrics.get("eta", 0.0)

                            if progress_callback:
                                progress_callback(rec_bytes, filesize, metrics)
                    elif msg_type == "TRANSFER_COMPLETE" or msg.get("status") in ("SUCCESS", "FAILED"):
                        final_ack_msg[0] = msg
                        break
                except (socket.timeout, TimeoutError):
                    continue
                except Exception:
                    break

        ack_thread = threading.Thread(target=_control_ack_listener, daemon=True)
        ack_thread.start()

        def _worker_stream(part_info):
            p_idx = part_info["part_index"]
            p_off = part_info["offset"]
            p_len = part_info["length"]

            wsock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                wsock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                wsock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, SOCKET_BUFFER_SIZE)
                wsock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, SOCKET_BUFFER_SIZE)
            except Exception:
                pass
            wsock.settimeout(60.0)

            try:
                wsock.connect((target_ip, target_port))
                send_message(wsock, {
                    "type": "PART_STREAM_HEADER",
                    "transfer_id": transfer_id,
                    "part_index": p_idx,
                    "offset": p_off,
                    "length": p_len
                })

                p_ack = receive_message(wsock)
                if not p_ack or p_ack.get("status") != "READY":
                    worker_errors.append(f"Worker {p_idx} handshake failed")
                    return

                with open(file_path, "rb", buffering=1024*1024) as f:
                    f.seek(p_off)
                    remaining = p_len
                    while remaining > 0:
                        chunk_size = min(BUFFER_SIZE, remaining)
                        chunk = f.read(chunk_size)
                        if not chunk:
                            break
                        wsock.sendall(chunk)
                        chunk_len = len(chunk)
                        remaining -= chunk_len

                        with bytes_sent_lock:
                            total_sent_bytes[0] += chunk_len
                            current_sent = total_sent_bytes[0]
                            transfer_record["transferred_bytes"] = current_sent

                            with ack_lock:
                                # If receiver ACKs haven't arrived yet (initial startup), report sent progress
                                if not received_any_ack[0]:
                                    transfer_record["received_bytes"] = current_sent
                                    metrics = processor.calculate_metrics(
                                        transferred_bytes=current_sent,
                                        total_bytes=filesize,
                                        start_time=start_time,
                                        transfer_id=transfer_id
                                    )
                                    transfer_record["progress_percent"] = metrics.get("percent", 0.0)
                                    transfer_record["speed"] = metrics.get("speed", 0.0)
                                    transfer_record["speed_mb"] = metrics.get("speed_mb", 0.0)
                                    transfer_record["speed_mbps"] = metrics.get("speed_mbps", 0.0)
                                    transfer_record["eta"] = metrics.get("eta", 0.0)

                                    if progress_callback:
                                        progress_callback(current_sent, filesize, metrics)

            except Exception as e:
                worker_errors.append(f"Worker {p_idx} error: {e}")
            finally:
                wsock.close()

        # Launch 4 worker threads concurrently
        threads = []
        for p in parts:
            t = threading.Thread(target=_worker_stream, args=(p,), daemon=True)
            threads.append(t)
            t.start()

        for t in threads:
            t.join()

        if worker_errors:
            ack_thread_stop.set()
            transfer_record["status"] = "FAILED"
            transfer_record["error_message"] = "; ".join(worker_errors)
            return False, f"Parallel transmission error: {'; '.join(worker_errors)}"

        # Wait for terminal ACK from server on control socket
        ack_thread.join(timeout=30.0)
        ack_thread_stop.set()

        final_ack = final_ack_msg[0]
        if not final_ack:
            try:
                control_sock.settimeout(10.0)
                final_ack = receive_message(control_sock)
            except Exception:
                pass

        if final_ack and final_ack.get("status") == "SUCCESS":
            transfer_record["status"] = "COMPLETED"
            transfer_record["transferred_bytes"] = filesize
            transfer_record["received_bytes"] = filesize
            transfer_record["progress_percent"] = 100.0
            transfer_record["speed"] = 0.0
            transfer_record["speed_mb"] = 0.0
            transfer_record["speed_mbps"] = 0.0
            transfer_record["eta"] = 0.0
            transfer_record["end_time"] = time.time()
            record_transfer(transfer_record)
            processor.reset_metrics_window(transfer_id)
            return True, f"File transferred successfully across {num_workers} parallel sockets."
        elif final_ack and final_ack.get("status") == "FAILED":
            err = final_ack.get('reason', 'Unknown server error')
            transfer_record["status"] = "FAILED"
            transfer_record["error_message"] = f"Peer error: {err}"
            return False, f"Peer error: {err}"

        return True, "Parallel stream complete."
    except Exception as e:
        transfer_record["status"] = "FAILED"
        transfer_record["error_message"] = f"Socket error: {e}"
        return False, f"Socket error: {e}"
    finally:
        control_sock.close()

def send_single_file(
    target_ip: str,
    file_path: str,
    rel_path: str = None,
    target_port: int = TCP_PORT,
    progress_callback = None
) -> tuple[bool, str]:
    """Send a single file with streaming Gzip compression and AES-GCM encryption."""
    if not os.path.exists(file_path):
        return False, f"File not found: {file_path}"

    filename = os.path.basename(file_path)
    relative_name = rel_path or filename
    filesize = os.path.getsize(file_path)

    # For large unencrypted files (>= 10MB), automatically dispatch 4-worker parallel streams
    use_encryption = state.encryption_enabled and bool(state.encryption_key)
    use_compression = state.compression_enabled and is_compressible_file(filename) and filesize > 1024

    if filesize >= PARALLEL_STREAMS_THRESHOLD and not use_encryption and not use_compression:
        return send_parallel_file(
            target_ip=target_ip,
            file_path=file_path,
            rel_path=rel_path,
            target_port=target_port,
            num_workers=PARALLEL_WORKERS,
            progress_callback=progress_callback
        )

    transfer_id = str(uuid.uuid4())
    file_checksum = compute_file_hash(file_path)

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, SOCKET_BUFFER_SIZE)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, SOCKET_BUFFER_SIZE)
    except Exception:
        pass
    sock.settimeout(30.0)

    # Register active outbound transfer record in state
    transfer_record = {
        "id": transfer_id,
        "filename": filename,
        "rel_path": relative_name,
        "filepath": file_path,
        "total_bytes": filesize,
        "received_bytes": 0,
        "transferred_bytes": 0,
        "progress_percent": 0.0,
        "direction": "OUTBOUND",
        "target_ip": target_ip,
        "status": "IN_PROGRESS",
        "encrypted": use_encryption,
        "compressed": use_compression,
        "speed": 0.0,
        "speed_mb": 0.0,
        "speed_mbps": 0.0,
        "eta": 0.0,
        "start_time": time.time(),
        "end_time": 0.0
    }
    state.transfers.insert(0, transfer_record)

    def _wrapped_progress(sent_bytes, total_bytes, metrics):
        transfer_record["transferred_bytes"] = sent_bytes
        transfer_record["received_bytes"] = sent_bytes
        transfer_record["progress_percent"] = metrics.get("percent", 0.0)
        transfer_record["speed"] = metrics.get("speed", 0.0)
        transfer_record["speed_mb"] = metrics.get("speed_mb", 0.0)
        transfer_record["speed_mbps"] = metrics.get("speed_mbps", 0.0)
        transfer_record["eta"] = metrics.get("eta", 0.0)
        if progress_callback:
            progress_callback(sent_bytes, total_bytes, metrics)

    try:
        sock.connect((target_ip, target_port))
        
        # Send FILE_HEADER
        send_message(sock, {
            "type": "FILE_HEADER",
            "transfer_id": transfer_id,
            "filename": filename,
            "rel_path": relative_name,
            "filesize": filesize,
            "is_compressed": use_compression,
            "is_encrypted": use_encryption,
            "checksum": file_checksum
        })

        # Wait for server response
        response = receive_message(sock)
        if not response or response.get("type") != "FILE_RESPONSE":
            transfer_record["status"] = "FAILED"
            transfer_record["error_message"] = "No response from receiving peer."
            return False, "No response from receiving peer."

        status = response.get("status")
        if status != "ACCEPT":
            reason = response.get("reason", "Declined")
            transfer_record["status"] = "FAILED"
            transfer_record["error_message"] = f"Peer rejected transfer: {reason}"
            return False, f"Peer rejected transfer: {reason}"

        resume_offset = response.get("resume_offset", 0)

        # Stream file data through processor
        ok, msg = processor.process_and_send_file(
            sock=sock,
            file_path=file_path,
            filesize=filesize,
            use_compression=use_compression,
            use_encryption=use_encryption,
            encryption_key=state.encryption_key,
            resume_offset=resume_offset,
            progress_callback=_wrapped_progress
        )

        if not ok:
            transfer_record["status"] = "FAILED"
            transfer_record["error_message"] = msg
            return False, msg

        # Wait for final ACK
        final_ack = receive_message(sock)
        if final_ack and final_ack.get("status") == "SUCCESS":
            transfer_record["status"] = "COMPLETED"
            transfer_record["transferred_bytes"] = filesize
            transfer_record["received_bytes"] = filesize
            transfer_record["progress_percent"] = 100.0
            transfer_record["speed"] = 0.0
            transfer_record["speed_mb"] = 0.0
            transfer_record["speed_mbps"] = 0.0
            transfer_record["eta"] = 0.0
            transfer_record["end_time"] = time.time()
            
            # Record outbound transfer in MongoDB
            record_transfer({
                "id": transfer_id,
                "filename": filename,
                "rel_path": relative_name,
                "filepath": file_path,
                "total_bytes": filesize,
                "direction": "OUTBOUND",
                "target_ip": target_ip,
                "status": "COMPLETED",
                "encrypted": use_encryption,
                "compressed": use_compression
            })
            return True, "File transferred and verified successfully."
        elif final_ack and final_ack.get("status") == "FAILED":
            err = final_ack.get('reason', 'Unknown error')
            transfer_record["status"] = "FAILED"
            transfer_record["error_message"] = f"Peer error: {err}"
            return False, f"Peer error: {err}"

        transfer_record["status"] = "COMPLETED"
        transfer_record["progress_percent"] = 100.0
        transfer_record["end_time"] = time.time()
        return True, "File stream completed."
    except Exception as e:
        transfer_record["status"] = "FAILED"
        transfer_record["error_message"] = f"Socket error: {e}"
        return False, f"Socket error: {e}"
    finally:
        sock.close()

def send_batch(
    target_ip: str,
    batch: BatchTransferTask,
    target_port: int = TCP_PORT,
    batch_progress_callback = None
) -> tuple[int, int]:
    """Send all tasks in a batch sequentially."""
    success_count = 0
    total_count = len(batch.tasks)

    for task in batch.tasks:
        if batch.status == TransferStatus.CANCELLED:
            break

        task.status = TransferStatus.IN_PROGRESS
        task.start_time = time.time()

        def _task_progress(sent_bytes, total_bytes, metrics):
            task.transferred_bytes = sent_bytes
            task.speed = metrics["speed"]
            task.eta = metrics["eta"]
            batch.update_aggregate_metrics()
            if batch_progress_callback:
                batch_progress_callback(batch, task, metrics)

        ok, msg = send_single_file(
            target_ip=target_ip,
            file_path=task.local_path,
            rel_path=task.relative_path,
            target_port=target_port,
            progress_callback=_task_progress
        )

        if ok:
            task.status = TransferStatus.COMPLETED
            task.transferred_bytes = task.filesize
            task.speed = 0.0
            task.eta = 0.0
            success_count += 1
        else:
            task.status = TransferStatus.FAILED
            task.error_message = msg
            task.speed = 0.0
            task.eta = 0.0

        task.end_time = time.time()
        batch.update_aggregate_metrics()

    return success_count, total_count

# Hook queue manager task executor
def _execute_queue_task(task: TransferTask):
    def _cb(sent_bytes, total_bytes, metrics):
        task.transferred_bytes = sent_bytes
        task.speed = metrics.get("speed", 0.0)
        task.eta = metrics.get("eta", 0.0)
        if task.batch_id:
            batch = queue_manager.get_batch(task.batch_id)
            if batch:
                batch.update_aggregate_metrics()

    ok, msg = send_single_file(
        target_ip=task.target_ip,
        file_path=task.local_path,
        rel_path=task.relative_path,
        progress_callback=_cb
    )
    if ok:
        task.status = TransferStatus.COMPLETED
        task.transferred_bytes = task.filesize
        task.speed = 0.0
        task.eta = 0.0
    else:
        task.status = TransferStatus.FAILED
        task.error_message = msg
        task.speed = 0.0
        task.eta = 0.0

    if task.batch_id:
        batch = queue_manager.get_batch(task.batch_id)
        if batch:
            batch.update_aggregate_metrics()

queue_manager.set_execution_handler(_execute_queue_task)
