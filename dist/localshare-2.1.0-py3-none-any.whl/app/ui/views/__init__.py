"""
LocalShare UI Views Package
"""
